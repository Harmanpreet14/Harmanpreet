<footer class="footer">
  <div class="container">
    <div class="row">
      <div class="col-sm-3">
        <div class="footer-widget">
          <h3>Stay in touch</h3>
          <div class="footer-widget-content">
            <a href="mailto:harmanpreet@booklover.com" class="contact-link">harmanpreet@booklover.com</a>
            <a href="mailto:support@booklover.com" class="contact-link limegreen"> support@booklover.com </a>
            <a href="tel:0121234" class="contact-link">(123) 456-789</a>
            <div class="footer-social">
              
              </div>
          </div>
        </div>
      </div>
      <div class="col-sm-3">
      <div class="footer-widget">
        <h3>Latest Events</h3>
        <div class="footer-widget-content">
          
         <div class="media">
              <div class="media-left">
                
              </div>
              <div class="media-body">
                 <p><a href="#">Live Demo for PHP Books </a></p>
                 <span>December 26, 2016 </span>
              </div>
           </div>
        </div>
        </div>
      </div>
      <div class="col-sm-3">
      <div class="footer-widget">
        <h3>Book Show Hours</h3>
        <div class="footer-widget-content">
        <div class="open-time ">
          <ul class="opening-time">
            <li><span><i class="fa fa-times"></i></span><p class="clock-time"><strong>Monday :</strong> closed</p>
             </li>
            <li><span><i class="fa fa-check"></i></span><p><strong>Tue-Fri :</strong> 8am - 12am</p></li>
            <li><span><i class="fa fa-check"></i></span><p><strong>Sat-Sun :</strong> 7am - 1am</p></li>
            <li><span><i class="fa fa-check"></i></span><p><strong>Holidays :</strong> 12pm-12am</p></li>
          </ul>
           </div>
        </div>
        </div></div>
      
      <div class="col-sm-3">
      <div class="footer-widget">
        <h3>Upcoming Sales</h3>
        <div class="footer-widget-content">
          <div class="images-gellary">
           <ul>
			<li>Boxing Day Books Discount 20%</li> 
			 <li>Christmis Special Books Sale </li> 
			</ul>
          </div>
        </div>
        </div>
      </div>
    </div>
  </div>
</footer>
<style>
.red{
  color: red !important;
}

footer{
  background-color: #333;
	color:whitesmoke;
  padding: 30px 0;
  .footer-widget{
    h3{
      margin-bottom: 30px;
    }
  }
  .contact-link{
    display:inline-block;
    width: 100%;
color:#333;
  }
  // footer social
  .footer-social{
    ul{
      padding-left: 0;
      li{
        list-style: none;
        float: left;
        padding: 0 10px;
        &:first-child{
          padding-left: 0;
        }
        a{
          font-size: 20px;
          color: #333;
          &:hover{
            color: red;
          }
        }
      }
    }
  }
  
  // opening hour
  .opening-time{
    padding-left:0;
    li{
      list-style: none;
      span{
        float:left;
        padding-right: 10px;
        .fa-times{
          color: #4CAF50;
        }
      }
        strong{
          color: #4CAF50;
        }
    }
  }
  
  // latest event
  .media-body{
    a{
      color: #333;
      &:hover{
        color: red;
      }
    }
    span{
        color: #969696;
      }
  }
  
  // gallery image
  .images-gellary{
    ul{
      padding-left: 0;
      li{
        list-style: none;
        float: left;
        margin: 0 3% 2% 0;
        width: 31%;
        position: relative;
        &:nth-child(3n) {
    margin: 0 0 1%;
}
        a{
          
        }
      }
    }
  }
}
</style>
