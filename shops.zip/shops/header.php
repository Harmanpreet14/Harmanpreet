<?php
session_start();
error_reporting(0);
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "BookStore";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) 
{
  die("Connection failed: " . $conn->connect_error);
}
 $quantityHeader = filter_var($_SESSION['item']['quantity'], FILTER_SANITIZE_STRING);

 $quantityHeader = empty($quantityHeader) ? 0 : $quantityHeader;
?>

