-- phpMyAdmin SQL Dump
-- version 5.0.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Oct 22, 2020 at 01:00 AM
-- Server version: 10.4.14-MariaDB
-- PHP Version: 7.4.10

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `bookstore`
--
CREATE DATABASE IF NOT EXISTS `bookstore` DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci;
USE `bookstore`;

-- --------------------------------------------------------

--
-- Table structure for table `bookinventory`
--

DROP TABLE IF EXISTS `bookinventory`;
CREATE TABLE IF NOT EXISTS `bookinventory` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `image` varchar(1000) NOT NULL,
  `quantity` int(11) NOT NULL,
  `currency` varchar(1) NOT NULL DEFAULT '$',
  `price` float NOT NULL,
  `status` tinyint(4) NOT NULL DEFAULT 1,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `bookinventory`
--

INSERT INTO `bookinventory` (`id`, `name`, `image`, `quantity`, `currency`, `price`, `status`) VALUES
(1, 'Phython', 'python.jpg', 2, '$', 100, 1),
(2, 'Angular JS\r\n', 'angular.jpg', 0, '$', 150, 1),
(3, 'Financial Accounting', 'account.jpg', 4, '$', 200, 1),
(4, 'The Mouse that was cat', 'kids.jpg', 24, '$', 350, 1),
(5, 'Java', 'java.gif\r\n', 0, '$', 430, 1),
(6, 'Christmas', 'christmas.jpg', 22, '$', 480, 1);

-- --------------------------------------------------------

--
-- Table structure for table `bookinventoryorder`
--

DROP TABLE IF EXISTS `bookinventoryorder`;
CREATE TABLE IF NOT EXISTS `bookinventoryorder` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `first_name` varchar(100) NOT NULL,
  `last_name` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `phone` varchar(20) NOT NULL,
  `quantity` int(11) NOT NULL,
  `payment` tinyint(4) NOT NULL,
  `book_date` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=37 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `bookinventoryorder`
--

INSERT INTO `bookinventoryorder` (`id`, `first_name`, `last_name`, `email`, `phone`, `quantity`, `payment`, `book_date`) VALUES
(27, 'Harmanpreet', 'Kaur', 'preet.harman14@gmail.com', '14379716911', 2, 1, '2020-10-21 18:35:58'),
(28, 'Harmanpreet', 'Kaur', 'preet.harman14@gmail.com', '14379716911', 6, 2, '2020-10-21 18:37:32'),
(29, 'Harmanpreet', 'Kaur', 'preet.harman14@gmail.com', '14379716911', 5, 2, '2020-10-21 18:39:42'),
(30, 'Harmanpreet', 'Kaur', 'preet.harman14@gmail.com', '14379716911', 2, 2, '2020-10-21 19:24:26'),
(31, 'Harmanpreet', 'Kaur', 'preet.harman14@gmail.com', '14379716911', 1, 2, '2020-10-21 19:25:03'),
(32, 'Harmanpreet', 'Kaur', 'preet.harman14@gmail.com', '14379716911', 1, 1, '2020-10-21 19:43:45'),
(33, 'Harmanpreet', 'Kaur', 'preet.harman14@gmail.com', '14379716911', 11, 1, '2020-10-21 22:13:54'),
(34, 'Harmanpreet', 'Kaur', 'preet.harman14@gmail.com', '14379716911', 1, 1, '2020-10-21 22:46:48'),
(35, 'Harmanpreet', 'Kaur', 'preet.harman14@gmail.com', '14379716911', 1, 2, '2020-10-21 22:54:12'),
(36, 'Harmanpreet', 'Kaur', 'preet.harman14@gmail.com', '14379716911', 1, 1, '2020-10-21 22:57:23');

-- --------------------------------------------------------

--
-- Table structure for table `payment`
--

DROP TABLE IF EXISTS `payment`;
CREATE TABLE IF NOT EXISTS `payment` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `payment_name` varchar(100) NOT NULL,
  `status` tinyint(4) NOT NULL DEFAULT 1,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `payment`
--

INSERT INTO `payment` (`id`, `payment_name`, `status`) VALUES
(1, 'ICICI Bank', 1),
(2, 'HDFC Bank', 1),
(3, 'COD', 1);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
