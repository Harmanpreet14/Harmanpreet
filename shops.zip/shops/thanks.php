<?php
require('header.php');
 session_destroy();
?>
<!DOCTYPE html>
<html class="no-js" lang="en" style="transition: .2s;">

<head>
     
    <style>
		.full {
    width: 100%;    
}
.gap {
	height: 30px;
	width: 100%;
	clear: both;
	display: block;
}

        .colorBar {
            height: 8px;
            background-color: #284e36;
        }

        * {
            box-sizing: border-box;
        }

        .zoom {
            padding: 10px;
            transition: transform .2s;
            border-radius: 8%;
        }

        .zoom:hover {
            -ms-transform: scale(1.05);
            /* IE 9 */
            -webkit-transform: scale(1.05);
            /* Safari 3-8 */
            transform: scale(1.05);
        }

        input[type=text],
        input[type=password] {
            width: 100%;
            padding: 12px 20px;
            margin: 8px 0;
            display: inline-block;
            border: 1px solid #ccc;
            box-sizing: border-box;
        }

        button {
            background-color: #284e36;
            color: white;
            padding: 14px 20px;
            margin: 8px 0;
            border: none;
            cursor: pointer;
            width: 100%;
        }

        button:hover {
            opacity: 0.8;
        }

        .cancelbtn {
            width: auto;
            padding: 10px 18px;
            background-color: #f44336;
        }

        .imgcontainer {
            text-align: center;
            margin: 24px 0 12px 0;
        }

        img.avatar {
            width: 40%;
            border-radius: 50%;
        }

        .container {
            padding: 16px;
        }

        span.psw {
            float: right;
            padding-top: 16px;
        }
        .navCust { 
            height: 27px;
            padding-top: 3px;
        }
        .navCust ul li {
            float: left;
            width: 100px;
            list-style: none;
        }
        .prod{
            border: 1px solid;
            margin: 5px;
            padding-bottom: 11px;
        }
        .butCustAd{
            margin-left: 5px;
        }
        .butCust{
            width: 80px;
            margin-bottom: 7px;
            float: right;
        }
        input.items {
    width: 72px;
}
    </style>
<meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>

    <!-- Google API Library -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.10.2/jquery.min.js"></script> 

</head>

<body id="top" class="with-sidebar-right home">
    
 <?php require('nav.php');?>

    <!--   S T A R T  O F  C O N T E N T   -->
    <div class="loginTable" style="height:500px;">
    
        <div class="container py-5"> 
            <div class="row">
                <div class="col-lg-2" style=" border-right: 1px solid #284e36;">
                     
                </div>
                <div class="col-lg-10">
					<h2>ORDER SUMMARY</h2>
                    Order number: #<?php echo str_pad($_SESSION['order_id'], 6, "0", STR_PAD_LEFT);?>
                    <div class="row container">Your order has successfully booked.
						
						<p>Thanks!!!  Enjoy Reading :)</p>
						<img src="./read.jpg" alt="Enjoy Reading" height="100px;width:100px">
                     </div>      
                </div>
            </div>
        </div>
    
    </div>
    
   
   <!-- Footer -->

    <!--/.footer-bottom--> 

   <!-- Footer -->
<?php require('footer.php'); ?>
<!-- Footer -->
</body>

</html>