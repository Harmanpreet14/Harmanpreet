<?php
require('header.php');
$error =  false;
 
 $item_id = filter_var($_SESSION['item']['pid'], FILTER_SANITIZE_STRING);
 $quantity = filter_var($_SESSION['item']['quantity'], FILTER_SANITIZE_STRING);

if($quantity<=0)
	header('location:store.php');

if(isset($_POST['action']) && $_POST['action'] == 'submit')
{ 
    $first_name = filter_var($_POST['fname'], FILTER_SANITIZE_STRING);
    $last_name = filter_var($_POST['lname'], FILTER_SANITIZE_STRING);
    $email = filter_var($_POST['email'], FILTER_SANITIZE_STRING);
    $phone = filter_var($_POST['phone'], FILTER_SANITIZE_STRING);
    $payment = filter_var($_POST['payment'], FILTER_SANITIZE_STRING);


    $sql = "INSERT INTO `BookInventoryOrder` (`first_name`, `last_name`, `email`, `phone`,`quantity`, `payment`) VALUES ( '".$first_name."', '".$last_name."', '".$email."', '".$phone."','".$quantity."', '".$payment."')";
    $result = $conn->query($sql); 
    if($result)
    {
        $last_id = $conn->insert_id;
        $_SESSION['order_id'] = $last_id;
        
        //update order quantity
         $sql = "update `BookInventory` set `quantity` = `quantity` - $quantity  WHERE `id` = $item_id";
         
        $conn->query($sql);
        header('location:thanks.php');
    }
    else
    {
        $error = true;
    }
}
?>
<!DOCTYPE html>
<html class="no-js" lang="en" style="transition: .2s;">

<head>
     
    <style>
		
		table
		{
			text-align: center;
			margin-top: 30px;
			margin-left: 50px;
			
		}
		table th
		{
			text-align: center;
			background-color: lightgray;
		}
		
        .colorBar {
            height: 8px;
            background-color: #284e36;
        }

        * {
            box-sizing: border-box;
        }

        .zoom {
            padding: 10px;
            transition: transform .2s;
            border-radius: 8%;
        }

        .zoom:hover {
            -ms-transform: scale(1.05);
            /* IE 9 */
            -webkit-transform: scale(1.05);
            /* Safari 3-8 */
            transform: scale(1.05);
        }

        input[type=text],
        input[type=password] {
            width: 100%;
            padding: 12px 20px;
            margin: 8px 0;
            display: inline-block;
            border: 1px solid #ccc;
            box-sizing: border-box;
        }

        button {
            background-color: #284e36;
            color: white;
            padding: 14px 20px;
            margin: 8px 0;
            border: none;
            cursor: pointer;
            width: 100%;
        }

        button:hover {
            opacity: 0.8;
        }

        .cancelbtn {
            width: auto;
            padding: 10px 18px;
            background-color: #f44336;
        }

        .imgcontainer {
            text-align: center;
            margin: 24px 0 12px 0;
        }

        img.avatar {
            width: 40%;
            border-radius: 50%;
        }

        .container {
            padding: 16px;
        }

        span.psw {
            float: right;
            padding-top: 16px;
        }
        .navCust { 
            height: 27px;
            padding-top: 3px;
        }
        .navCust ul li {
            float: left;
            width: 100px;
            list-style: none;
        }
        .prod{
            border: 1px solid;
            margin: 5px;
            padding-bottom: 11px;
        }
        .butCustAd{
            margin-left: 5px;
        }
        .butCust{
            width: 80px;
            margin-bottom: 7px;
            float: right;
        }
        ul.payment li {
    list-style: none;
}
        input.items {
    width: 72px;
}
 
    </style>
<meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>

    <!-- Google API Library -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.10.2/jquery.min.js"></script> 
<script type="text/javascript">
    function cancel()
    { 
        window.location.href='store.php';
    }
    $(document).ready(function(){
        $('#form').submit(function(e){
             if($('#fname').val() == "")
             {
                alert('Please enter First Name');
                e.preventDefault();
             }
             if($('#lname').val() == "")
             {
                alert('Please enter Last Name');
                e.preventDefault();
             }
            if($('#email').val() == "")
             {
                alert('Please enter Email');
                e.preventDefault();
             }
              if($('#phone').val() == "")
             {
                alert('Please enter Phone Number');
                e.preventDefault();
             }
             if($('input[name="payment"]:checked').length == 0)
             {
                alert('Please select payment option.');
                e.preventDefault();
             }
        });
    });

    function updateCart(pid)
    { 
       var quantity = $('#quantity'+pid).val();
       var max = $('#quantity'+pid).attr('max');
       if(  parseInt(quantity)<=0)
       {
        alert('Invalid quantity.');
		   $('#checkout').hide();
		   return false;
       }
       if(  parseInt(quantity) > parseInt(max) )
       {
        alert('Invalid quantity.');
       }
       else
		   {
			   $('#checkout').show();
          window.location.href='store.php?edit=yes&item='+pid+'&quantity='+quantity; 
		   }
    }
</script>
</head>

<body id="top" class="with-sidebar-right home">
    <?php require('nav.php');?>


    <!--   S T A R T  O F  C O N T E N T   -->
    <div class="loginTable" style="height:600px">
    
        <div class="container py-5">
    
<!--
    <div class="row">
        <div class="col-lg-2" style=" border-right: 1px solid #284e36;">
             
        </div>
-->
        <div>
             <form method="post" name="form" id="form">
             
             
                <div class="row"> 
                     <div class="col-sm-8">
                        <div class="form-group col-md-12">
                            <table width="100%" border="1" height="300px;" >
                                <tr>
                                    <th>Item</th>
                                    <th style="align:center">Quantity</th>
                                    <th style="align:center">Price</th>
                                </tr>
                                <?php
 $id = isset($item_id) ?$item_id : 0;

                        $sql = "SELECT * FROM `BookInventory` where  status = 1 and id=$id ";
                        $result = $conn->query($sql);

                        
                                    $rowp = $result->fetch_assoc();
                                     
                                ?>
                                <tr>
                                    <td><?php echo $rowp['name']; ?></td>
                                    <td><input type="number" max="<?php echo $rowp['quantity']; ?>" min="1" value="<?php echo (isset( $quantityHeader ) && empty( $quantityHeader ) ? 1 :  $quantityHeader )?>" name="quantity<?php echo $rowp['id']; ?>" onchange="updateCart(<?php echo $rowp['id']; ?>)" id="quantity<?php echo $rowp['id']; ?>"></td>
                                    <td><?php echo $rowp['price']; ?></td>
                                </tr>
                                <tr>
                                     
                                    <th align="right" colspan="2">Total</th>
                                    <th><?php echo $rowp['currency'].($rowp['price'] * $quantity ) ; ?></th>
                                </tr>

                            </table>
                            <div style="margin-top: 10px;float: right;/* width: 48%; */">
                              
                              <button id="checkout"  type="button" class="btn btn-primary" onclick="javascript:window.location.href='checkout.php'">Checkout</button>
                            </div>
                        </div>
                     </div>
                    <div class="col-sm-4"></div>
                </div>
           
             
        </form>        
        </div>
    </div>
</div>
    
    </div>
    </body>
   
   <!-- Footer -->
<?php require('footer.php'); ?>
<!-- Footer -->


</html>