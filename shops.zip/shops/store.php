<?php
require('header.php');

if(isset($_GET['item']) && $_GET['item'] > 0)
{
    $_SESSION['item']['pid'] = $_GET['item'];
    $_SESSION['item']['quantity'] = $_GET['quantity'];
	$_SESSION['image']['image']=$_GET['image'];

    if(isset($_GET['edit']) && $_GET['edit'] == 'yes')
        header('location:edit.php');
    else
        header('location:checkout.php');
    die;
}

?>
<!DOCTYPE html>
<html class="no-js" lang="en" style="transition: .2s;">

<head>
     
    <style>
        .colorBar {
            height: 8px;
            background-color: #284e36;
        }

        * {
            box-sizing: border-box;
        }

        .zoom {
            padding: 10px;
            transition: transform .2s;
            border-radius: 8%;
        }

        .zoom:hover {
            -ms-transform: scale(1.05);
            /* IE 9 */
            -webkit-transform: scale(1.05);
            /* Safari 3-8 */
            transform: scale(1.05);
        }

        input[type=text],
        input[type=password] {
            width: 100%;
            padding: 12px 20px;
            margin: 8px 0;
            display: inline-block;
            border: 1px solid #ccc;
            box-sizing: border-box;
        }

        button {
            background-color: #284e36;
            color: white;
            padding: 14px 20px;
            margin: 8px 0;
            border: none;
            cursor: pointer;
            width: 100%;
        }

        button:hover {
            opacity: 0.8;
        }

        .cancelbtn {
            width: auto;
            padding: 10px 18px;
            background-color: #f44336;
        }

        .imgcontainer {
            text-align: center;
            margin: 24px 0 12px 0;
        }

        img.avatar {
            width: 40%;
            border-radius: 50%;
        }

        .container {
            padding: 16px;
        }

        span.psw {
            float: right;
            padding-top: 16px;
        }
        .navCust { 
            height: 27px;
            padding-top: 3px;
        }
        .navCust ul li {
            float: left;
            width: 100px;
            list-style: none;
        }
        .prod{
            border: 1px solid;
            margin: 5px;
            padding-bottom: 11px;
        }
        .butCustAd{
            margin-left: 5px;
        }
        .butCust{
            width: 80px;
            margin-bottom: 7px;
            float: right;
        }
        input.items {
    width: 72px;
}
    </style>
<meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script type="text/javascript">
    function addCart(pid)
    {
         
         
       var quantity = $('#quantity'+pid).val();
       var max = $('#quantity'+pid).attr('max');
       if(  parseInt(quantity)<=0)
       {
        alert('Invalid quantity.');
		   return false;
       }
       if(  parseInt(quantity) > parseInt(max) )
       {
        alert('Invalid quantity.');
       }
       else
          window.location.href='store.php?edit=yes&item='+pid+'&quantity='+quantity;
         
    }
</script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>

    <!-- Google API Library -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.10.2/jquery.min.js"></script> 

</head>

<body id="top" class="with-sidebar-right home">
     <?php require('nav.php');?>


    <!--   S T A R T  O F  C O N T E N T   -->
    <div class="loginTable" style="height:550px;">
    
        <div class="container py-5">
    
    <div class="row">
        <div class="col-lg-2" style=" border-right: 1px solid #284e36;">
             
        </div>
        <div class="col-lg-10">
            <div class="row container">
            <!-- List group-->
            
                <?php
                 
                $sql = "SELECT * FROM `BookInventory` where  status = 1 ";
                $result = $conn->query($sql);

                if ($result->num_rows > 0) 
				{
                  // output data of each row
                  while($rowp = $result->fetch_assoc()) 
				  { 
					?>
                  
                    <!-- Custom content-->
                    <div class="col-sm-4 prod" style="height: 129px;"> 
                        <div class="col-sm-6" style="    margin-left: -15px;
">
                            <h5 style="color:blue;font-weight: bold;"><?php echo $rowp['name']; ?></h5>
                        <p class="font-italic text-muted mb-0 small">
                            Available quantity: <?php echo $rowp['quantity']; ?></p>
                        <p class="font-italic text-muted mb-0 small">Price: <?php echo $rowp['currency'].''.$rowp['price']; ?></p>
                        <?php
                        if($rowp['quantity']>0)
                        {
                        ?>
                        <p  style="float: left;" class="font-italic text-muted mb-0 small">
							<input type="number" max="<?php echo $rowp['quantity']; ?>" min="1" value="<?php echo (isset( $quantityHeader ) && empty( $quantityHeader ) ? 1 :  $quantityHeader )?>" name="quantity<?php echo $rowp['id']; ?>" id="quantity<?php echo $rowp['id']; ?>"></p>
                         
                        <a  style="float: right;color:blue;background-color:lightgrey;width:50px;text-align:center" href="javascript:void(0)" onclick="addCart(<?php echo $rowp['id']; ?>)">Buy</a> 
                        <?php
                        }
                        else
                        {
                            ?>
                               <p class="font-italic text-muted mb-0 large " style="color:red"><b>Sold Out!!!</b></p>  
                            <?php 
                        }

                        ?>
                        </div>
                        <div class="col-sm-6">
                            <img  style=" margin-top: 6%;" src="<?php echo $rowp['image']; ?>" width="150" height="110">
                        </div>
                    </div> <!-- End -->
                 
                <?php
                }
                } else 
				{
                  echo " Item not found.";
                }
                ?> 
             
            </div>        
        </div>
        
    </div>
</div>
    
    </div>
    
    
    <!-- Footer -->
<?php require('footer.php'); ?>
<!-- Footer -->

</body>

</html>